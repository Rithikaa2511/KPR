document.getElementById("analyzeBtn").addEventListener("click", function() {
    const input = document.getElementById("dataInput").value;
    if(!input) {
        alert("Please enter some numbers.");
        return;
    }

    // Convert input string into an array of numbers
    const data = input.split(',').map(num => parseFloat(num.trim())).filter(num => !isNaN(num));

    if(data.length === 0) {
        alert("Please enter valid numbers separated by commas.");
        return;
    }

    // Calculate statistics
    const sum = data.reduce((a, b) => a + b, 0);
    const avg = (sum / data.length).toFixed(2);
    const max = Math.max(...data);
    const min = Math.min(...data);

    // Display results
    document.getElementById("results").innerHTML = `
        Total numbers: ${data.length} <br>
        Sum: ${sum} <br>
        Average: ${avg} <br>
        Maximum: ${max} <br>
        Minimum: ${min}
    `;
});
